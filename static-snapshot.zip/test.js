let a = '[[wewewe[w[e]]]';
console.log(a.split('['));